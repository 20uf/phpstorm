/**
${PARAM_DOC}
#if (${TYPE_HINT} != "self") * @return ${TYPE_HINT}
#end
${THROWS_DOC}
*/
